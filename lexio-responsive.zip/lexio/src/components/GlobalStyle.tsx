import { Theme, tokens } from "../tokens";

interface GlobalStyleProps {
  theme: Theme;
}

export const GlobalStyle = ({ theme }: GlobalStyleProps) => {
  const t = tokens[theme];
  const bgGradient = theme === "dark"
    ? "radial-gradient(ellipse at 20% 50%, #1a0f0a 0%, #0a0908 100%)"
    : "radial-gradient(ellipse at 20% 50%, #f0e8e0 0%, #e8e2d9 100%)";

  return (
    <style>{`
      @import url('https://fonts.googleapis.com/css2?family=DM+Serif+Display:ital@0;1&family=DM+Sans:wght@300;400;500;600&display=swap');

      * { box-sizing: border-box; margin: 0; padding: 0; }

      :root {
        --bg: ${t.bg};
        --surface: ${t.surface};
        --surface-alt: ${t.surfaceAlt};
        --border: ${t.border};
        --text: ${t.text};
        --text-sub: ${t.textSub};
        --text-muted: ${t.textMuted};
        --accent: ${t.accent};
        --accent-soft: ${t.accentSoft};
        --accent-gold: ${t.accentGold};
        --accent-blue: ${t.accentBlue};
        --accent-green: ${t.accentGreen};
        --streak: ${t.streak};
        --card1: ${t.card1};
        --card1-text: ${t.card1text};
        --sidebar-w: 0px;
      }

      html, body { height: 100%; }
      body {
        font-family: 'DM Sans', sans-serif;
        background: var(--bg);
        color: var(--text);
        min-height: 100vh;
      }

      .serif { font-family: 'DM Serif Display', serif; }

      /* ════════════════════════════════════════════
         MOBILE  <768px  — full-screen, bottom nav
         ════════════════════════════════════════════ */
      .app-shell {
        display: flex;
        min-height: 100vh;
        background: var(--bg);
      }

      .sidebar { display: none; }

      .main-area {
        flex: 1;
        display: flex;
        flex-direction: column;
        padding-bottom: 76px;
      }

      .screen {
        width: 100%;
        padding: 56px 20px 24px;
        animation: fadeIn 0.3s ease;
        flex: 1;
      }

      .nav-bar {
        position: fixed;
        bottom: 0; left: 0; right: 0;
        background: var(--surface);
        border-top: 1px solid var(--border);
        display: flex;
        align-items: center;
        justify-content: space-around;
        padding: 10px 0 env(safe-area-inset-bottom, 14px);
        z-index: 200;
      }

      .nav-item {
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 3px;
        cursor: pointer;
        transition: all 0.2s;
        padding: 6px 14px;
        border-radius: 12px;
        -webkit-tap-highlight-color: transparent;
      }
      .nav-item.active { background: var(--accent-soft); }
      .nav-item span { font-size: 10px; font-weight: 500; color: var(--text-muted); }
      .nav-item.active span { color: var(--accent); }

      /* ════════════════════════════════════════════
         TABLET  768px–1199px  — phone card centred
         ════════════════════════════════════════════ */
      @media (min-width: 768px) {
        body { background: ${bgGradient}; }

        .app-shell {
          align-items: center;
          justify-content: center;
          min-height: 100vh;
        }

        .main-area {
          width: 420px;
          min-height: 840px;
          max-height: 92vh;
          border-radius: 40px;
          overflow: hidden;
          overflow-y: auto;
          box-shadow: 0 40px 100px rgba(0,0,0,0.3);
          position: relative;
          padding-bottom: 80px;
          scrollbar-width: none;
          background: var(--bg);
        }
        .main-area::-webkit-scrollbar { display: none; }

        .nav-bar {
          position: absolute;
          bottom: 0; left: 0; right: 0;
          border-radius: 0 0 40px 40px;
        }

        .screen { padding: 60px 28px 24px; max-width: 100%; }
      }

      /* ════════════════════════════════════════════
         DESKTOP  ≥1200px  — persistent left sidebar
         ════════════════════════════════════════════ */
      @media (min-width: 1200px) {
        :root { --sidebar-w: 252px; }

        body { background: ${bgGradient}; overflow: hidden; }

        .app-shell {
          width: 100vw;
          height: 100vh;
          flex-direction: row;
          align-items: stretch;
          justify-content: flex-start;
        }

        /* ── Sidebar ── */
        .sidebar {
          display: flex;
          flex-direction: column;
          width: var(--sidebar-w);
          min-height: 100vh;
          background: var(--surface);
          border-right: 1px solid var(--border);
          padding: 28px 14px 28px;
          flex-shrink: 0;
          position: fixed;
          top: 0; left: 0; bottom: 0;
          z-index: 100;
        }

        .sidebar-logo {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 0 10px;
          margin-bottom: 32px;
        }
        .sidebar-logo-mark {
          width: 34px; height: 34px;
          border-radius: 10px;
          background: var(--accent);
          display: flex; align-items: center; justify-content: center;
          font-size: 16px; flex-shrink: 0;
        }
        .sidebar-logo span {
          font-family: 'DM Serif Display', serif;
          font-size: 20px;
          color: var(--text);
        }

        .sidebar-section-label {
          font-size: 10px;
          font-weight: 600;
          letter-spacing: 1px;
          color: var(--text-muted);
          padding: 0 12px;
          margin: 16px 0 6px;
          text-transform: uppercase;
        }

        .sidebar-item {
          display: flex;
          align-items: center;
          gap: 10px;
          padding: 11px 14px;
          border-radius: 12px;
          cursor: pointer;
          transition: all 0.16s;
          color: var(--text-sub);
          font-size: 14px;
          font-weight: 500;
          margin-bottom: 2px;
        }
        .sidebar-item:hover  { background: var(--surface-alt); color: var(--text); }
        .sidebar-item.active { background: var(--accent-soft); color: var(--accent); }
        .sidebar-item.active svg { stroke: var(--accent) !important; }

        .sidebar-spacer { flex: 1; }

        .sidebar-bottom {
          border-top: 1px solid var(--border);
          padding-top: 12px;
          display: flex;
          flex-direction: column;
          gap: 2px;
        }

        /* Hide bottom nav */
        .nav-bar { display: none !important; }

        /* Main content area */
        .main-area {
          margin-left: var(--sidebar-w);
          flex: 1;
          height: 100vh;
          max-height: 100vh;
          overflow-y: auto;
          width: auto;
          border-radius: 0;
          box-shadow: none;
          padding-bottom: 0;
          background: var(--bg);
          scrollbar-width: thin;
          scrollbar-color: var(--border) transparent;
        }

        .screen {
          max-width: 720px;
          padding: 44px 48px 56px;
        }

        /* Desktop grid helpers */
        .desktop-two-col {
          display: grid;
          grid-template-columns: 1fr 1fr;
          gap: 16px;
        }
        .desktop-three-col {
          display: grid;
          grid-template-columns: 1fr 1fr 1fr;
          gap: 14px;
        }
      }

      /* ════════════════════════════════════════════
         WIDE  ≥1600px
         ════════════════════════════════════════════ */
      @media (min-width: 1600px) {
        :root { --sidebar-w: 280px; }
        .screen { max-width: 860px; padding: 52px 64px 64px; }
      }

      /* ─── Animations ─── */
      @keyframes fadeIn  { from { opacity:0; transform:translateY(8px);  } to { opacity:1; transform:translateY(0);  } }
      @keyframes slideUp { from { opacity:0; transform:translateY(20px); } to { opacity:1; transform:translateY(0);  } }
      @keyframes float   { 0%,100% { transform:translateY(0px); } 50% { transform:translateY(-6px); } }
      @keyframes shimmer { 0% { background-position:-200% center; } 100% { background-position:200% center; } }

      /* ─── Shared components ─── */
      .word-card {
        background: var(--card1);
        color: var(--card1-text);
        border-radius: 24px;
        padding: 32px 28px;
        position: relative;
        overflow: hidden;
        cursor: pointer;
        transition: transform 0.2s;
      }
      .word-card:active { transform: scale(0.98); }
      .word-card::before {
        content: '';
        position: absolute;
        top: -40px; right: -40px;
        width: 160px; height: 160px;
        border-radius: 50%;
        background: rgba(255,255,255,0.04);
      }

      .surface-card {
        background: var(--surface);
        border: 1px solid var(--border);
        border-radius: 20px;
        padding: 20px;
        transition: transform 0.2s, box-shadow 0.2s;
        cursor: pointer;
      }
      .surface-card:hover  { box-shadow: 0 4px 20px rgba(0,0,0,0.07); }
      .surface-card:active { transform: scale(0.98); }

      .accent-btn {
        background: var(--accent);
        color: white;
        border: none;
        border-radius: 16px;
        padding: 16px 24px;
        font-family: 'DM Sans', sans-serif;
        font-size: 15px;
        font-weight: 600;
        cursor: pointer;
        transition: transform 0.15s, opacity 0.15s;
        display: flex;
        align-items: center;
        justify-content: center;
        gap: 8px;
        width: 100%;
      }
      .accent-btn:hover  { opacity: 0.92; }
      .accent-btn:active { transform: scale(0.97); }

      .ghost-btn {
        background: var(--surface-alt);
        color: var(--text);
        border: none;
        border-radius: 16px;
        padding: 16px 24px;
        font-family: 'DM Sans', sans-serif;
        font-size: 15px;
        font-weight: 500;
        cursor: pointer;
        transition: all 0.15s;
        width: 100%;
      }

      .streak-badge {
        display: flex;
        align-items: center;
        gap: 6px;
        background: var(--accent-soft);
        border-radius: 12px;
        padding: 6px 12px;
      }

      .tag {
        background: var(--surface-alt);
        border-radius: 8px;
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 500;
        color: var(--text-sub);
      }

      .progress-bar-wrap {
        background: var(--surface-alt);
        border-radius: 100px;
        height: 6px;
        overflow: hidden;
      }
      .progress-bar-fill {
        height: 100%;
        border-radius: 100px;
        background: var(--accent);
        transition: width 0.5s ease;
      }

      .rarity-common { color: var(--text-sub); }
      .rarity-rare   { color: var(--accent-blue); }
      .rarity-epic   { color: #A855F7; }
      .rarity-legendary {
        background: linear-gradient(90deg, var(--accent-gold), #FF5733, #A855F7);
        background-size: 200% auto;
        -webkit-background-clip: text;
        -webkit-text-fill-color: transparent;
        animation: shimmer 2s linear infinite;
      }

      .collection-card {
        border-radius: 16px;
        padding: 16px;
        display: flex;
        flex-direction: column;
        align-items: center;
        gap: 8px;
        position: relative;
        overflow: hidden;
        cursor: pointer;
        transition: transform 0.2s;
      }
      .collection-card:hover  { transform: translateY(-3px); }
      .collection-card:active { transform: scale(0.95); }
      .collection-card.locked { opacity: 0.5; filter: grayscale(1); }

      .quiz-option {
        background: var(--surface);
        border: 2px solid var(--border);
        border-radius: 16px;
        padding: 16px 20px;
        cursor: pointer;
        transition: all 0.15s;
        font-size: 15px;
        font-weight: 500;
        color: var(--text);
        display: flex;
        align-items: center;
        gap: 12px;
        text-align: left;
        width: 100%;
        font-family: 'DM Sans', sans-serif;
      }
      .quiz-option:hover   { border-color: var(--accent); background: var(--accent-soft); }
      .quiz-option.correct { border-color: var(--accent-green); background: rgba(34,197,94,0.08); color: var(--accent-green); }
      .quiz-option.wrong   { border-color: #EF4444; background: rgba(239,68,68,0.08); color: #EF4444; }

      ::-webkit-scrollbar       { width: 5px; }
      ::-webkit-scrollbar-track { background: transparent; }
      ::-webkit-scrollbar-thumb { background: var(--border); border-radius: 100px; }
    `}</style>
  );
};
