import { Home, Layers, Brain, Sparkles, User, Settings, BookMarked, Zap, Moon, Sun } from "lucide-react";
import { Theme } from "../tokens";

export type ScreenId = "home" | "cards" | "quiz" | "collect" | "profile";

interface NavBarProps {
  active: ScreenId;
  setActive: (id: ScreenId) => void;
  theme: Theme;
  setTheme: React.Dispatch<React.SetStateAction<Theme>>;
}

const mainItems: { id: ScreenId; icon: React.ElementType; label: string }[] = [
  { id: "home",    icon: Home,     label: "Главная"   },
  { id: "cards",   icon: Layers,   label: "Карточки"  },
  { id: "quiz",    icon: Brain,    label: "Квиз"      },
  { id: "collect", icon: Sparkles, label: "Коллекция" },
  { id: "profile", icon: User,     label: "Профиль"   },
];

const secondaryItems = [
  { icon: BookMarked, label: "Словарь"   },
  { icon: Zap,        label: "Уд. режим" },
  { icon: Settings,   label: "Настройки" },
];

export const NavBar = ({ active, setActive, theme, setTheme }: NavBarProps) => {
  const iconColor = (id: ScreenId) => active === id ? "var(--accent)" : "var(--text-muted)";
  const strokeW   = (id: ScreenId) => active === id ? 2.5 : 1.8;

  return (
    <>
      {/* ── Desktop sidebar ── */}
      <aside className="sidebar">
        <div className="sidebar-logo">
          <div className="sidebar-logo-mark">📖</div>
          <span>Lexio</span>
        </div>

        <p className="sidebar-section-label">Обучение</p>
        <nav className="sidebar-nav" style={{ display: "flex", flexDirection: "column" }}>
          {mainItems.map(({ id, icon: Icon, label }) => (
            <div
              key={id}
              className={`sidebar-item ${active === id ? "active" : ""}`}
              onClick={() => setActive(id)}
            >
              <Icon size={18} strokeWidth={active === id ? 2.5 : 1.8} color={active === id ? "var(--accent)" : "var(--text-sub)"} />
              {label}
            </div>
          ))}
        </nav>

        <p className="sidebar-section-label">Инструменты</p>
        <div style={{ display: "flex", flexDirection: "column" }}>
          {secondaryItems.map(({ icon: Icon, label }) => (
            <div key={label} className="sidebar-item">
              <Icon size={18} strokeWidth={1.8} color="var(--text-sub)" />
              {label}
            </div>
          ))}
        </div>

        <div className="sidebar-spacer" />

        <div className="sidebar-bottom">
          <div
            className="sidebar-item"
            onClick={() => setTheme(t => t === "light" ? "dark" : "light")}
          >
            {theme === "light"
              ? <Moon size={18} strokeWidth={1.8} color="var(--text-sub)" />
              : <Sun  size={18} strokeWidth={1.8} color="var(--text-sub)" />}
            {theme === "light" ? "Тёмная тема" : "Светлая тема"}
          </div>
        </div>
      </aside>

      {/* ── Mobile / Tablet bottom nav ── */}
      <nav className="nav-bar">
        {mainItems.map(({ id, icon: Icon, label }) => (
          <div
            key={id}
            className={`nav-item ${active === id ? "active" : ""}`}
            onClick={() => setActive(id)}
          >
            <Icon size={20} strokeWidth={strokeW(id)} color={iconColor(id)} />
            <span>{label}</span>
          </div>
        ))}
      </nav>
    </>
  );
};
