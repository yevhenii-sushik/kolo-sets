import { useState } from "react";
import { Flame, Check, X, ArrowRight } from "lucide-react";

const options = [
  "преходящий, мимолётный",
  "огромный, грандиозный",
  "хаотичный, беспорядочный",
  "тихий, безмолвный",
];
const CORRECT = 0;
const LETTERS = ["A", "B", "C", "D"];

export const QuizScreen = () => {
  const [selected, setSelected] = useState<number | null>(null);

  const getClass = (i: number) => {
    if (selected === null) return "quiz-option";
    if (i === CORRECT) return "quiz-option correct";
    if (i === selected) return "quiz-option wrong";
    return "quiz-option";
  };

  return (
    <div className="screen">
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
          <h2 style={{ fontSize: 22, fontWeight: 700 }}>Квиз</h2>
          <div className="streak-badge">
            <Flame size={14} color="var(--streak)" />
            <span style={{ fontSize: 13, fontWeight: 700, color: "var(--accent)" }}>×3 серия</span>
          </div>
        </div>
        <div className="progress-bar-wrap">
          <div className="progress-bar-fill" style={{ width: "40%" }} />
        </div>
        <div style={{ display: "flex", justifyContent: "space-between", marginTop: 6 }}>
          <span style={{ fontSize: 11, color: "var(--text-muted)" }}>Вопрос 4 из 10</span>
          <span style={{ fontSize: 11, color: "var(--accent-green)", fontWeight: 600 }}>3 верных</span>
        </div>
      </div>

      {/* Question */}
      <div style={{
        background: "var(--surface)", border: "1px solid var(--border)",
        borderRadius: 24, padding: "32px 28px", marginBottom: 20, textAlign: "center",
      }}>
        <p style={{ fontSize: 11, color: "var(--text-muted)", letterSpacing: 1, fontWeight: 600, marginBottom: 12 }}>
          ПЕРЕВЕДИ СЛОВО
        </p>
        <p className="serif" style={{ fontSize: 44, fontWeight: 400, marginBottom: 8 }}>Ephemeral</p>
        <p style={{ fontSize: 13, color: "var(--text-sub)", fontStyle: "italic" }}>
          "The ephemeral beauty of cherry blossoms."
        </p>
      </div>

      {/* Options — 1 col mobile, 2 col desktop */}
      <div style={{
        display: "grid",
        gridTemplateColumns: "repeat(auto-fill, minmax(260px, 1fr))",
        gap: 10,
      }}>
        {options.map((opt, i) => (
          <button
            key={i}
            className={getClass(i)}
            onClick={() => selected === null && setSelected(i)}
          >
            <span style={{
              width: 28, height: 28, borderRadius: 8, background: "var(--surface-alt)",
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 12, fontWeight: 700, flexShrink: 0,
            }}>
              {selected !== null && i === CORRECT
                ? <Check size={14} />
                : selected !== null && i === selected && i !== CORRECT
                  ? <X size={14} />
                  : LETTERS[i]}
            </span>
            {opt}
          </button>
        ))}
      </div>

      {selected !== null && (
        <div style={{ marginTop: 16, maxWidth: 400, animation: "slideUp 0.3s ease" }}>
          <button className="accent-btn">
            Следующий вопрос <ArrowRight size={16} />
          </button>
        </div>
      )}
    </div>
  );
};
