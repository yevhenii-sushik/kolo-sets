import { useState } from "react";
import { RotateCcw, Check, X } from "lucide-react";

interface FlashCard {
  word: string;
  trans: string;
  example: string;
  pos: string;
  lang: string;
}

const cards: FlashCard[] = [
  { word: "Sonder",   trans: "осознание того, что у каждого прохожего своя сложная жизнь", example: "Walking through the city, she felt a deep sonder.", pos: "noun", lang: "EN" },
  { word: "Laconic",  trans: "лаконичный, краткий",                                         example: "His laconic reply surprised everyone.",           pos: "adj",  lang: "EN" },
  { word: "Hiraeth",  trans: "ностальгия по дому, которого никогда не существовало",         example: "She felt hiraeth every autumn evening.",         pos: "noun", lang: "CY" },
];

export const CardsScreen = () => {
  const [flipped, setFlipped]     = useState(false);
  const [cardIndex, setCardIndex] = useState(0);

  const card = cards[cardIndex % cards.length];
  const next = () => { setCardIndex(i => i + 1); setFlipped(false); };

  return (
    <div className="screen">
      {/* Header */}
      <div style={{ marginBottom: 24 }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <h2 style={{ fontSize: 22, fontWeight: 700 }}>Карточки</h2>
          <div style={{ display: "flex", gap: 8 }}>
            <span className="tag">EN → RU</span>
            <span className="tag">32 слова</span>
          </div>
        </div>
      </div>

      {/* Progress */}
      <div style={{ marginBottom: 20 }}>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontSize: 12, color: "var(--text-sub)" }}>Прогресс сессии</span>
          <span style={{ fontSize: 12, fontWeight: 600 }}>{cardIndex + 1} / {cards.length}</span>
        </div>
        <div className="progress-bar-wrap">
          <div className="progress-bar-fill" style={{ width: `${((cardIndex + 1) / cards.length) * 100}%` }} />
        </div>
      </div>

      {/* Card — max-width on desktop so it doesn't get too wide */}
      <div
        onClick={() => setFlipped(f => !f)}
        className="word-card"
        style={{ minHeight: 240, display: "flex", flexDirection: "column", justifyContent: "space-between", marginBottom: 16, maxWidth: 560 }}
      >
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <span style={{ fontSize: 11, opacity: 0.4, letterSpacing: 1, fontWeight: 600 }}>{flipped ? "ПЕРЕВОД" : "СЛОВО"}</span>
          <span style={{ fontSize: 11, opacity: 0.4 }}>{card.lang} · {card.pos}</span>
        </div>

        {!flipped ? (
          <div>
            <p className="serif" style={{ fontSize: 42, fontWeight: 400, lineHeight: 1.1, marginBottom: 8 }}>{card.word}</p>
            <p style={{ fontSize: 13, opacity: 0.4, fontStyle: "italic" }}>Нажми, чтобы открыть</p>
          </div>
        ) : (
          <div style={{ animation: "slideUp 0.25s ease" }}>
            <p style={{ fontSize: 20, fontWeight: 600, lineHeight: 1.4, marginBottom: 12 }}>{card.trans}</p>
            <p style={{ fontSize: 13, opacity: 0.5, fontStyle: "italic", lineHeight: 1.5 }}>"{card.example}"</p>
          </div>
        )}

        <div style={{ display: "flex", alignItems: "center", gap: 6, opacity: 0.3 }}>
          <RotateCcw size={12} />
          <span style={{ fontSize: 11 }}>{flipped ? "показать слово" : "показать перевод"}</span>
        </div>
      </div>

      {flipped && (
        <div style={{
          display: "grid", gridTemplateColumns: "1fr 1fr 1fr",
          gap: 10, maxWidth: 400,
          animation: "slideUp 0.25s ease",
        }}>
          {([
            { label: "Трудно", color: "#EF4444",             bg: "rgba(239,68,68,0.08)",  icon: X         },
            { label: "Ок",     color: "var(--text-sub)",     bg: "var(--surface-alt)",    icon: RotateCcw },
            { label: "Легко",  color: "var(--accent-green)", bg: "rgba(34,197,94,0.08)", icon: Check     },
          ] as const).map(({ label, color, bg, icon: Icon }) => (
            <button
              key={label}
              onClick={next}
              style={{
                background: bg, border: "none", borderRadius: 16, padding: "14px 8px",
                cursor: "pointer", display: "flex", flexDirection: "column",
                alignItems: "center", gap: 6,
              }}
            >
              <Icon size={18} color={color} strokeWidth={2.5} />
              <span style={{ fontSize: 12, fontWeight: 600, color }}>{label}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
