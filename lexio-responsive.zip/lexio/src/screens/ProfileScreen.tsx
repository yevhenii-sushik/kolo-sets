import { Flame } from "lucide-react";

const stats = [
  { label: "Слов",     value: "347" },
  { label: "Квизов",   value: "89"  },
  { label: "Карточек", value: "12"  },
];

const achievements = [
  { icon: "🔥", name: "Неделя огня",  desc: "7 дней подряд",   done: true  },
  { icon: "📚", name: "Полиглот",     desc: "100 слов",         done: true  },
  { icon: "⚡", name: "Молния",       desc: "10 слов за 5 мин", done: false },
  { icon: "🏆", name: "Чемпион",      desc: "500 слов",         done: false },
  { icon: "🌙", name: "Ночная сова",  desc: "Учи после полуночи",done: true },
  { icon: "🎯", name: "Точность",     desc: "10 квизов на 100%", done: false },
];

export const ProfileScreen = () => (
  <div className="screen">
    {/* Avatar + info */}
    <div style={{ display: "flex", alignItems: "center", gap: 20, marginBottom: 28 }}>
      <div style={{
        width: 76, height: 76, borderRadius: 24, background: "var(--card1)",
        display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0,
      }}>
        <span style={{ fontSize: 34 }}>🧑‍💻</span>
      </div>
      <div>
        <h2 style={{ fontSize: 24, fontWeight: 700 }}>Алекс</h2>
        <p style={{ fontSize: 13, color: "var(--text-sub)", marginBottom: 8 }}>Уровень 12 · Продвинутый</p>
        <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
          <div className="streak-badge">
            <Flame size={12} color="var(--streak)" />
            <span style={{ fontSize: 12, fontWeight: 700, color: "var(--accent)" }}>24 дня</span>
          </div>
          <span className="tag">🇬🇧 English</span>
          <span className="tag">🇩🇪 Deutsch</span>
        </div>
      </div>
    </div>

    {/* Stats — auto cols */}
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))",
      gap: 10, marginBottom: 24,
    }}>
      {stats.map(({ label, value }) => (
        <div key={label} style={{
          background: "var(--surface)", border: "1px solid var(--border)",
          borderRadius: 16, padding: "14px 12px", textAlign: "center",
        }}>
          <p className="serif" style={{ fontSize: 26, fontWeight: 400, marginBottom: 2 }}>{value}</p>
          <p style={{ fontSize: 11, color: "var(--text-muted)", fontWeight: 500 }}>{label}</p>
        </div>
      ))}
    </div>

    {/* XP bar */}
    <div style={{
      background: "var(--surface)", border: "1px solid var(--border)",
      borderRadius: 20, padding: "18px 20px", marginBottom: 24,
    }}>
      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 10 }}>
        <span style={{ fontWeight: 600, fontSize: 14 }}>Опыт до ур. 13</span>
        <span style={{ fontSize: 13, color: "var(--accent)", fontWeight: 700 }}>2 340 / 3 000 XP</span>
      </div>
      <div className="progress-bar-wrap" style={{ height: 8 }}>
        <div className="progress-bar-fill" style={{ width: "78%" }} />
      </div>
    </div>

    {/* Achievements — 2 col mobile, 3 col desktop */}
    <p style={{ fontWeight: 600, fontSize: 15, marginBottom: 12 }}>Ачивки</p>
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(180px, 1fr))",
      gap: 10,
    }}>
      {achievements.map(({ icon, name, desc, done }) => (
        <div key={name} style={{
          background: "var(--surface)",
          border: `1px solid ${done ? "var(--accent)" : "var(--border)"}`,
          borderRadius: 16, padding: "14px 16px",
          display: "flex", alignItems: "center", gap: 12,
          opacity: done ? 1 : 0.5,
          transition: "opacity 0.2s",
        }}>
          <span style={{ fontSize: 24, flexShrink: 0 }}>{icon}</span>
          <div>
            <p style={{ fontSize: 13, fontWeight: 600, marginBottom: 2 }}>{name}</p>
            <p style={{ fontSize: 11, color: "var(--text-sub)" }}>{desc}</p>
          </div>
        </div>
      ))}
    </div>
  </div>
);
