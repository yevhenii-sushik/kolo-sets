import { Flame, Zap, BookMarked, Globe, Trophy, Moon, Sun } from "lucide-react";
import { Theme } from "../tokens";

interface HomeScreenProps {
  theme: Theme;
  setTheme: React.Dispatch<React.SetStateAction<Theme>>;
}

const words = [
  { word: "Ephemeral",   trans: "мимолётный",             lang: "EN", progress: 70 },
  { word: "Serendipity", trans: "счастливая случайность", lang: "EN", progress: 30 },
  { word: "Petrichor",   trans: "запах земли после дождя",lang: "EN", progress: 55 },
];

const quickActions = [
  { icon: Zap,        label: "Ударный режим", color: "var(--accent-gold)",  bg: "rgba(245,166,35,0.1)"  },
  { icon: BookMarked, label: "Словарь",       color: "var(--accent-blue)",  bg: "rgba(59,130,246,0.1)"  },
  { icon: Globe,      label: "Истории",       color: "var(--accent-green)", bg: "rgba(34,197,94,0.1)"   },
  { icon: Trophy,     label: "Ачивки",        color: "#A855F7",             bg: "rgba(168,85,247,0.1)"  },
];

export const HomeScreen = ({ theme, setTheme }: HomeScreenProps) => (
  <div className="screen">
    {/* Header */}
    <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 28 }}>
      <div>
        <p style={{ fontSize: 13, color: "var(--text-sub)", fontWeight: 500, marginBottom: 4 }}>Доброе утро</p>
        <h1 className="serif" style={{ fontSize: 28, fontWeight: 400, letterSpacing: "-0.5px" }}>
          Алекс <span style={{ fontStyle: "italic", color: "var(--accent)" }}>👋</span>
        </h1>
      </div>
      <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
        <div className="streak-badge">
          <Flame size={14} color="var(--streak)" />
          <span style={{ fontSize: 13, fontWeight: 700, color: "var(--accent)" }}>24</span>
        </div>
        {/* Theme toggle — shown on mobile/tablet only (desktop uses sidebar) */}
        <button
          onClick={() => setTheme(t => t === "light" ? "dark" : "light")}
          style={{
            background: "var(--surface-alt)", border: "none", borderRadius: 12,
            padding: 10, cursor: "pointer", display: "flex",
          }}
          className="mobile-theme-toggle"
        >
          {theme === "light"
            ? <Moon size={16} color="var(--text-sub)" />
            : <Sun  size={16} color="var(--text-sub)" />}
        </button>
        <style>{`@media (min-width: 1200px) { .mobile-theme-toggle { display: none !important; } }`}</style>
      </div>
    </div>

    {/* Daily goal */}
    <div className="word-card" style={{ marginBottom: 16 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 16 }}>
        <div>
          <p style={{ fontSize: 11, opacity: 0.5, fontWeight: 500, marginBottom: 6, letterSpacing: 1 }}>СЕГОДНЯШНЯЯ ЦЕЛЬ</p>
          <p className="serif" style={{ fontSize: 34, fontWeight: 400 }}>12 <span style={{ fontSize: 16, opacity: 0.6 }}>слов</span></p>
        </div>
        <div style={{ background: "rgba(255,255,255,0.08)", borderRadius: 14, padding: "8px 12px" }}>
          <p style={{ fontSize: 11, opacity: 0.5, marginBottom: 2 }}>изучено</p>
          <p style={{ fontSize: 20, fontWeight: 700 }}>7/12</p>
        </div>
      </div>
      <div className="progress-bar-wrap">
        <div className="progress-bar-fill" style={{ width: "58%" }} />
      </div>
      <p style={{ fontSize: 12, opacity: 0.4, marginTop: 8 }}>Осталось 5 слов до выполнения цели</p>
    </div>

    {/* Quick actions — 2 col on mobile, 4 col on desktop */}
    <div style={{ marginBottom: 24 }}>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(130px, 1fr))", gap: 10 }}>
        {quickActions.map(({ icon: Icon, label, color, bg }) => (
          <div key={label} className="surface-card" style={{ padding: 16 }}>
            <div style={{ background: bg, borderRadius: 12, width: 40, height: 40, display: "flex", alignItems: "center", justifyContent: "center", marginBottom: 10 }}>
              <Icon size={18} color={color} />
            </div>
            <p style={{ fontSize: 13, fontWeight: 600 }}>{label}</p>
          </div>
        ))}
      </div>
    </div>

    {/* Recent words */}
    <div style={{ marginBottom: 16, display: "flex", justifyContent: "space-between", alignItems: "center" }}>
      <p style={{ fontWeight: 600, fontSize: 15 }}>Недавние слова</p>
      <p style={{ fontSize: 13, color: "var(--accent)", fontWeight: 500, cursor: "pointer" }}>Все →</p>
    </div>

    {/* On desktop show 3 words in a responsive grid */}
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 10 }}>
      {words.map(({ word, trans, lang, progress }) => (
        <div key={word} className="surface-card">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
            <div>
              <p style={{ fontWeight: 700, fontSize: 16 }}>{word}</p>
              <p style={{ color: "var(--text-sub)", fontSize: 13, marginTop: 2 }}>{trans}</p>
            </div>
            <span className="tag">{lang}</span>
          </div>
          <div className="progress-bar-wrap">
            <div className="progress-bar-fill" style={{ width: `${progress}%` }} />
          </div>
        </div>
      ))}
    </div>
  </div>
);
