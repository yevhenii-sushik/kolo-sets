import { Sparkles, Star, Lock } from "lucide-react";

type Rarity = "common" | "rare" | "epic" | "legendary";

interface CollCard {
  name: string;
  emoji: string;
  rarity: Rarity;
  rarityLabel: string;
  owned: boolean;
  bg: string;
}

const cards: CollCard[] = [
  { name: "Сократ",   emoji: "🏛️", rarity: "legendary", rarityLabel: "Легенда", owned: true,  bg: "linear-gradient(135deg,#667eea,#764ba2)" },
  { name: "Шекспир",  emoji: "📜", rarity: "epic",      rarityLabel: "Эпик",    owned: true,  bg: "linear-gradient(135deg,#f093fb,#f5576c)" },
  { name: "Тесла",    emoji: "⚡", rarity: "rare",      rarityLabel: "Редкий",  owned: true,  bg: "linear-gradient(135deg,#4facfe,#00f2fe)" },
  { name: "Да Винчи", emoji: "🎨", rarity: "legendary", rarityLabel: "Легенда", owned: true,  bg: "linear-gradient(135deg,#fa709a,#fee140)" },
  { name: "???",      emoji: "🌌", rarity: "legendary", rarityLabel: "Легенда", owned: false, bg: "var(--surface-alt)" },
  { name: "???",      emoji: "📚", rarity: "epic",      rarityLabel: "Эпик",    owned: false, bg: "var(--surface-alt)" },
  { name: "???",      emoji: "🔭", rarity: "rare",      rarityLabel: "Редкий",  owned: false, bg: "var(--surface-alt)" },
  { name: "???",      emoji: "🧪", rarity: "common",    rarityLabel: "Обычная", owned: false, bg: "var(--surface-alt)" },
];

const rarityItems: [string, Rarity][] = [
  ["Обычная", "common"],
  ["Редкая",  "rare"],
  ["Эпик",    "epic"],
  ["Легенда", "legendary"],
];

export const CollectScreen = () => (
  <div className="screen">
    <div style={{ marginBottom: 8 }}>
      <h2 style={{ fontSize: 22, fontWeight: 700, marginBottom: 4 }}>Коллекция</h2>
      <p style={{ fontSize: 13, color: "var(--text-sub)" }}>Собирай карточки за изучение слов</p>
    </div>

    {/* Drop timer */}
    <div style={{
      background: "var(--surface)", border: "1px solid var(--border)",
      borderRadius: 20, padding: "16px 18px", marginBottom: 20,
      display: "flex", alignItems: "center", gap: 14,
    }}>
      <div style={{ background: "rgba(245,166,35,0.12)", borderRadius: 14, padding: 10, flexShrink: 0 }}>
        <Sparkles size={20} color="var(--accent-gold)" />
      </div>
      <div style={{ flex: 1 }}>
        <p style={{ fontWeight: 600, fontSize: 14, marginBottom: 2 }}>Следующий дроп через</p>
        <p className="serif" style={{ fontSize: 22, color: "var(--accent-gold)" }}>2ч 14м</p>
      </div>
      <div style={{ textAlign: "right" }}>
        <p style={{ fontSize: 11, color: "var(--text-muted)" }}>бонус шанс</p>
        <p style={{ fontSize: 13, fontWeight: 700, color: "#A855F7" }}>×1.5</p>
      </div>
    </div>

    {/* Rarity legend */}
    <div style={{ display: "flex", gap: 8, marginBottom: 20, flexWrap: "wrap" }}>
      {rarityItems.map(([label, cls]) => (
        <div key={cls} style={{
          display: "flex", alignItems: "center", gap: 6,
          background: "var(--surface)", borderRadius: 10, padding: "5px 10px",
        }}>
          <Star size={10} className={`rarity-${cls}`} style={{ fill: "currentColor" }} />
          <span className={`rarity-${cls}`} style={{ fontSize: 11, fontWeight: 600 }}>{label}</span>
        </div>
      ))}
    </div>

    {/* Grid — auto columns: 3 mobile, 4 tablet, 5-6 desktop */}
    <div style={{
      display: "grid",
      gridTemplateColumns: "repeat(auto-fill, minmax(100px, 1fr))",
      gap: 12,
    }}>
      {cards.map((card, i) => (
        <div
          key={i}
          className={`collection-card ${!card.owned ? "locked" : ""}`}
          style={{ background: card.bg }}
        >
          {!card.owned && (
            <div style={{
              position: "absolute", inset: 0, display: "flex", alignItems: "center",
              justifyContent: "center", borderRadius: 16, background: "rgba(0,0,0,0.3)",
            }}>
              <Lock size={18} color="white" />
            </div>
          )}
          <span style={{
            fontSize: 30,
            animation: card.owned ? `float 3s ease-in-out ${i * 0.3}s infinite` : "none",
          }}>
            {card.emoji}
          </span>
          <p style={{ fontSize: 11, fontWeight: 700, color: card.owned ? "white" : "var(--text)", textAlign: "center" }}>
            {card.name}
          </p>
          <span className={`rarity-${card.rarity}`} style={{ fontSize: 10, fontWeight: 600 }}>
            {card.rarityLabel}
          </span>
        </div>
      ))}
    </div>
  </div>
);
