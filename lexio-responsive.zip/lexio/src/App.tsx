import { useState } from "react";
import { GlobalStyle } from "./components/GlobalStyle";
import { NavBar, ScreenId } from "./components/NavBar";
import { HomeScreen }    from "./screens/HomeScreen";
import { CardsScreen }   from "./screens/CardsScreen";
import { QuizScreen }    from "./screens/QuizScreen";
import { CollectScreen } from "./screens/CollectScreen";
import { ProfileScreen } from "./screens/ProfileScreen";
import { Theme } from "./tokens";

export default function App() {
  const [theme, setTheme]   = useState<Theme>("dark");
  const [screen, setScreen] = useState<ScreenId>("home");

  const screens: Record<ScreenId, React.ReactNode> = {
    home:    <HomeScreen theme={theme} setTheme={setTheme} />,
    cards:   <CardsScreen />,
    quiz:    <QuizScreen />,
    collect: <CollectScreen />,
    profile: <ProfileScreen />,
  };

  return (
    <>
      <GlobalStyle theme={theme} />
      <div className="app-shell">
        {/* Desktop sidebar lives inside NavBar */}
        <NavBar
          active={screen}
          setActive={setScreen}
          theme={theme}
          setTheme={setTheme}
        />

        {/* Main scrollable content */}
        <main className="main-area">
          {screens[screen]}
        </main>
      </div>
    </>
  );
}
